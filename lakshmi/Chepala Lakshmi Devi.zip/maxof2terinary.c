#include<stdio.h>

int main()
{
int num1,num2,max;

printf("\enter 2 numbers::");
scanf("%d%d",&num1,num2);

(num1>num2)?printf("\nnum1 is greater"):("\nnum2 is greater");


return 0;
}