#include<stdio.h>
int main()
{
     float sales,com,salary;
     float com_rate;
     printf("enter the sales:");
     scanf("%f",&sales);
     if(sales==20000)
            com_rate=0.20;
     else if(sales>=15000 && sales<20000)
            com_rate=0.15;
     else if(sales>=10000 && sales<15000)
            com_rate=0.10;
     else if(sales>=8000 && sales<10000)
            com_rate=0.08;
     else if(sales>=5000 && sales<8000)
            com_rate=0.05;
     else if(sales<5000)
     com_rate=0.00;
     com=com_rate*sales;
     printf("salary is %f\n",salary);
     return 0;
}
