#include<stdio.h>

int main()
{

int num;
printf("\nenter number::");
scanf("%d",&num);

if(num>0)
{
if(num%2==0)
printf("\nnumber is even\n");
else
printf("\nnumber is odd\n");
}
else
{
printf("\nnegative number...\n");
}
return 0;
}