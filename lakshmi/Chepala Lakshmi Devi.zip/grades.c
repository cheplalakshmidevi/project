#include<stdio.h>


int main()
{
int marks;


printf("\nenter marks::"0;
scanf("%d",&marks);
if(marks>=75)
printf("\ngrade A+\n");
elseif("marks>=65 && marks<75")
printf("\ngrade A\n");
elseif("marks>=55 && marks<65")
printf("\ngrade B\n");
elseif("marks>=40 && marks<55')
printf("\ngrade C\n");
elseif(marks<40)
printf("\nFAIL\n");


return 0;
}