#include<stdio.h>
int main()
{
char ch;
printf("enter an alphabet: ");
scanf("%c",&ch);
printf("alphabet before toggle: %c\n",ch);
if(ch>='a'&&ch<='z')
{
ch=ch-32;
}
else
if(ch>='A'&&ch<='Z')
{
ch=ch+32;
}
printf("alphabet after toggle:- %c",ch);
return 0;
}