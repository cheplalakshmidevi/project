#include<stdio.h>
#include<conio.h>
int main()
{
float sp,cp,pf,ls;
printf("enter cp,sp :");
scanf("%f%f",&cp&sp);
if(sp>cp)
{
pf = sp-cp;
printf("profit = %.2f", pf);
}
else if(cp>sp)
{
ls = cp-sp;
printf("loss=%.2f", ls);
}
else
printf("no profit and loss.");
getch();
return 0;
}
