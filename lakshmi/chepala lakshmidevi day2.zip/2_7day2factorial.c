#include<stdio.h>
int main()
{
int i,j,factorial=2;
for(i=2;i<=7;i++)
{
for(j=1;j<=i;j++)
{
factorial=factorial*j;
}
printf("\n %d",factorial);
factorial=1;
}
return 0;
}