#include<stdio.h>
int main()
{
int n,i,factorial=1;
printf("enter an integer:");
scanf("%d",&n);

if(n<0)
  printf("factorial of negative number doesn't exist.");

  else
{
 for(i=1;i<=n;++i)
{
 factorial*=i;
}
 printf("factorial of %d=%d",n,factorial);
}

  return 0;
}