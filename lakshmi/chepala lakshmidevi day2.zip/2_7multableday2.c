#include<stdio.h>

int main()
{
  int i, j, product;
	
	 for(i=2;i<=7;i++)
	 {
		  for(j=1;j<=10;j++)
		  {
			   product = i*j;
			   printf("%d x %d = %d\t", i, j, product);
		  }
		  printf("\n\n");
	 }
	 
	 return(0);
}