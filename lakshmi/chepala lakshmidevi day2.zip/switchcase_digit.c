#include<stdio.h>
int main()
{
int digit;
printf("\nenter your choice:");
scanf("%d",&digit);
  switch(digit)
{
  case 0:
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
         printf("you entered a digit");
         break;
         default;
         printf("not digit");
}
return 0;
}
  

