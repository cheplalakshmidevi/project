#include<stdio.h>
int main()
{
 int i,j;
  for(i='A',j='a';i<=90&&j<=122;i++,j++)
printf("\n%c   %c",i,j);


return 0;
}