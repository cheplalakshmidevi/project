#include<stdio.h>
#include<string.h>
int count(char *);
int main()
{
    char s[20];
    int c =0,i;
    
    printf("enter the string:\n");
    fgets(s,20,stdin);
    count(s);
    return 0;
}
int count(char *s)
{
    int i,c=0;
    for (i=0;s[i]!='\0';i++)
    {
        if (s[i]==' ' && s[i+1] !=' ')
        c++;
    }
printf("number of words in given string are:%d\n", c+1);
}