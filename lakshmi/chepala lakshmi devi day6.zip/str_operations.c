#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define STRLEN 1
#define STRCOPY 2
#define STRCAT 3
#define STRCMP 4
#define STRREV 5
#define EXIT 0

int strlength(char*);
int strcopy(char*,char*);
int strconcat(char*,char*);
int strcomp(char*,char*);
int strreve(char*);


int main()
{
    char str1[20],str2[20];
    int choice,len;
    
    printf("\nenter 2 strings::");
    fgets(str1,20,stdin);
    str1[strlen(str1)-1]='\0';
    
    fgets(str2,20,stdin);
    str2[strlen(str2)-1]='\0';
    
    printf("\n........menu........");
    printf("\n1:strlen\
           \n2:strcpy\
           \n3:strconcat\
           \n4:strcomp\
           \n5:strreve\
           \n0:EXIT");
    printf("\nenter your choice");
    scanf("%d",&choice);
    
    switch(choice)
    {
        case STRLEN:
           {        
             len=strlength(str1);
             printf("\nlength::%d",len);
             break;
           }
        case STRCOPY:
        {
            strcopy(str1,str2);
            printf("\nafter copying str1::%s",str1);
            break;
        }
        case STRCAT:
        {
           strconcat(str1,str2);
            printf("\nafter concatenation str1::%s",str1);
            break;
        }
        case STRCMP:
        {
            int ans;
            ans=strcomp(str1,str2);
            if(ans==0)
            printf("\nstrings are same");
            else
            printf("\nstrings are not same");
            break;
        }
        case STRREV:
        {
            strreve(str1);
            printf("string reverse is %s",str1);
            break;
        }
        case EXIT:
            exit(0);
        default:
            printf("\n\tinvalid choice....!!!!");
    }
    return 0;
    
    
}
int strlength(char *str1)
{
    int i;
    for(i=0;str1[i]!='\0';i++);
    return i;
}
int strcopy(char*str1,char*str2)
{
    int i;
    for(i=0;str2[i]!='\0';i++);
    str1[i]=str2[i];
    str1[i]='\0';
}
int strconcat(char *str1,char*str2)
{
    int i,j;
    i=strlength(str1);
    for(j=0;str2[j]!='\0';j++,i++)
    str1[i]=str2[j];
    str1[i]='\0';
}
int strcomp(char*str1,char*str2)
{
    int len1,len2;
    int i=0,j=0;
    
    len1 = strlength(str1);
    len2 = strlength(str2);
    
    if(len1==len2)
    {
       while(str1[i]!='\0' && (str1[i]==str2[j]))
       {
           i++;
           j++;
       }
       if(i!=len1)
       return 1;
       else 
       return 0;
    }
       else
       return 1;
}
int strreve(char*str1)
{
    int i,len,temp;
    len=strlen(str1);
    for(i=0;i<len/2;i++)
    {
        temp=str1[i];
        str1[i]=str1[len-i-1];
        str1[len-i-1]=temp;
    }
    }
