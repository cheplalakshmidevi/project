#include<stdio.h>
#include<stdio.h>

void strrev(char*);

int main()
{
    char str1[20];
    printf("\nenter the string");
    fgets(str1,20,stdin);
    str1[strlen(str1)-1]='\0';
    printf("\nstring is %s",str1);
    
    strrev(str1);
    printf("\n after string reverse: %s",str1);
    
    return 0;
}
void strrev(char *str1)
{
    int i,len,temp;
    len=strlen(str1);
    for(i=0;i<len/2;i++)
    {
        temp=str1[i];
        str1[i]=str1[len-i-1];
        str1[len-i-1]=temp;
    }
}
    