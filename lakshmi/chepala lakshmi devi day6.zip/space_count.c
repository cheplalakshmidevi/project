#include<stdio.h>
#include<stdlib.h>
int main()
{
    char str[100];
    int i;
    int space=0;
    printf("enter a string\n");
    gets(str);
    i=0;
    while(i<str[i])
    {
        if(str[i]==' ')
        {
            space++;
        }
        i++;
    }
    printf("total white space:%d",space);
    return 0;
}