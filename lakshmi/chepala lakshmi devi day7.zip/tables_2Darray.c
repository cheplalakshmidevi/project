#include<stdio.h>
#define ROW 7
#define COL 10
int main()
{
    int arr[7][10];
    int i,j;
    printf("enterthe values\n");
    for(i=2;i<=ROW;i++)
    {
        for(j=1;j<=COL;j++)
        {
            printf("%d*%d=%d\n",i,j,i*j);
        }
        
        }
    return 0;
}