#include<stdio.h>
int main()
{
    char alpha[2][26];
    int i,j;
    int letter=65;
    for(i=0;i<26;i++,letter++)
    {
        
            alpha[0][i]=letter;
            alpha[1][i]=letter+32;
            
        }
        printf("\nalphabets::\n");
        for(i=0;i<2;i++)
        {
            for(j=0;j<26;j++)
            {
                printf("%c",alpha[i][j]);
        }
        printf("\n");
    }
return 0;
}