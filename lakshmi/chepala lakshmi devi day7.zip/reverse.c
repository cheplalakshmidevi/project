#include<stdio.h>
#define ROW 1
#define COL 3

int main()
{
    int arr[ROW][COL];
    int i,j;
    int num;
    printf("\nenterthe 3 digit number:");
    for(i=0;i<ROW;i++)
    {
        scanf("%d",&num);
        
    }
     for(i=0;i<ROW;i++)
    {
        for(j=0;j<COL;j++)
        {
            arr[i][j]=num%10;
            num=num/10;
        }
    }
    printf("after reversing\n");
    for(i=0;i<ROW;i++)
    {
       for(j=0;j<COL;j++)
   {
       printf("%d",arr[i][j]);
   }
   printf("\n");
    }
    return 0;
        }
        
