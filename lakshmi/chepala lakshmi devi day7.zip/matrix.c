#include<stdio.h>
#define ROW 3
#define COL 3
int accept1(int(*)[COL],int);
int accept2(int(*)[COL],int);
int display1(int(*)[COL],int row);
int display2(int(*)[COL],int row);
void sum_matrices(int (*)[COL],int (*)[COL],int);
int main()
{
     int arr1[ROW][COL],arr2[ROW][COL],sum[ROW][COL];
     accept1(arr1,ROW);
     accept2(arr2,ROW);
     display1(arr1,ROW);
     display2(arr2,ROW);
     sum_matrices(arr1,arr2,ROW);
     return 0;
}
int accept1(int(*arr1)[COL],int row)
{
    int i,j;
    printf("\n enter elements into matrix1 :");
    for(i=0;i<row;i++)
    {
        for(j=0;j<COL;j++)
        {
            scanf("%d",&arr1[i][j]);
        }
    }
}
int accept2(int(*arr2)[COL],int row)
{
    int i,j;
    printf("\n enter elements into matrix2 :");
    for(i=0;i<row;i++)
    {
        for(j=0;j<COL;j++)
        {
            scanf("%d",&arr2[i][j]);
        }
    }
}
int display1(int(*arr1)[COL],int row)
{
    int i,j;
    printf("\n  elements in matrix1 :");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&arr1[i][j]);
        }
    }
}

int display2(int(*arr2)[COL],int row)
{
    int i,j;
    printf("\n  elements in matrix2 :");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&arr2[i][j]);
        }
    }
}
void sum_matrices(int(*arr1)[COL],int (*arr2)[COL],int row)
{
    int i,j;
    printf("\n sum of matrices result:");
    for(i=0;i<row;i++)
    {
        for(j=0;j<COL;j++)
        {
            printf("%d",(arr1[i][j]+arr2[i][j]));
        }
    }
}
    
