#include<stdio.h>
int sum(int n);
int main()
{
    int num;
    printf("enter number:");
    scanf("%d",&num);
    printf("sum of digits %d : %d",num,sum(num));
    return 0;
}
int sum(int n)
{
    if(n!=0)
    {
        return n+sum(n-1);
    }
    else
    return n;
}
    