#include<stdio.h>
void even_odd(int,int*,int*);
int main()
{
int limit,even=0,odd=0;

printf("\nenter the limit\n");
scanf("%d",&limit);

even_odd(limit,&even,&odd);

printf("\nsum of even=%d\nsum of odd=%d\n",even,odd);

return 0;
}
void even_odd(int limit,int*even,int*odd)
{
int i;
for(i=1;i<=limit;i++)
{
if(i%2==0)
*even=(*even)+i;
else
*odd=(*odd)+i;
}
return 0;
}