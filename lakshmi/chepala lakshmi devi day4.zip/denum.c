#include<stdio.h>
void result(int*,int*,int*,int*);
int main()
{
    int dividend,divisor,quotient,remainder;
    printf("enter dividend: ");
    scanf("%d",&dividend);
    printf("enter divisor: ");
    scanf("%d",&divisor);
result(&dividend,&divisor,&quotient,&remainder);
printf("quotient=%d\n",quotient);
printf("remainder=%d\n",remainder);

}
void result(int*dividend,int*divisor,int*quotient,int*remainder)
{
    
 *quotient=*dividend/ *divisor;
    *remainder=*dividend% *divisor;

}