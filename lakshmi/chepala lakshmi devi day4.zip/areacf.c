#include<stdio.h>
void circle(float,float*,float*);
void square(float,float*,float*);
void triangle(float,float,float,float,float,float*,float*);
void rectangle(float,float,float*,float*);
int main()
{
    int ch;
    float radius,area,cf,side,perimeter,breadth,height,x,y,z,length,width;
    printf("calculate the area and circumferences of geometrical shapes\n");
    printf("enter the choice\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:

printf("enterthe radius\n");
        scanf("%f",&radius);
        circle(radius,&area,&cf);
        printf("the area of the circle is %f",area);
        printf("\n the circumference of a circle is %f",cf);
        break;

        case 2:

        printf("enter the side of a square\n");
        scanf("%f",&side);
        circle(side,&area,&perimeter);
        printf("the perimeter of the square is %f",perimeter);
        printf("area of the square:%0.4f\n",area);
        break;

        case :3

         printf("enter the base and height of triangle\n");
        scanf("%f %f",&breadth,&height);
        printf("area of the triangle:%f\n",area);
         
         printf("enter sides of a triangle=%f\n");
         scanf("%f %f %f",&x,&y,&z);
        
        printf("the perimeter of the triangle is %f",perimeter);
        triangle(breadth,height,x,y,z,&area,&perimeter);

        case:4
printf("enter length of rectangle\n");
scanf("%f",&length);
printf("enter width of rectangle\n");
scanf("%f",&width);
rectangle(length,width,&area,&perimeter);
printf("area of rectangle:%0.4f\n",area);
printf("perimeter of rectangle :%0.4f\n",perimeter);
break;
}
return 0;

}

circle(float radius,float*area,float*cf)
{
*area=3.14*radius*radius;
*cf=2*3.14*radius;
}
square(float side,float*area,float*perimeter)
{
*perimeter=4*side;
*area=side*side;
}
triangle(float breadth,float height,float x,float y,float z,float *area,float*perimeter)
{
*area=(breadth*height)/2;
*perimeter=x+y+z;
}
rectangle(float length,float width,float*area,float*perimeter)
{
*area=length*breadth;
*perimeter=2*(length+width);
}