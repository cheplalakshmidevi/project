#include<stdio.h>
int factorial(int);
int main()
{
    int num,result;
    printf("enter number:");
    scanf("%d",&num);
    result=factorial(num);
    printf("factorial of %d:%d",num,result);
    return 0;
}
int sum=0,r;
int factorial(int n)
{
    if(n==0)
    {
        return 1;
    }
    else
{
    return(n*factorial(n-1));
    
}
}