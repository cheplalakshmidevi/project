#include<stdio.h>
int reverse(int);
int main()
{
int num,result;
printf("enter number:");
scanf("%d",&num);
result=reverse(num);
printf("reverse of digits %d:%d",num,result);
return 0;
}
int sum=0,r;
int reverse(int n)
{
if(n!=0)
{
r=n%10;
sum=sum*10+r;
reverse(n/10);
}
else
{
return sum;
}
}