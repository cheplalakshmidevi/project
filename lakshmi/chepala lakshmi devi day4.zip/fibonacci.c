#include<stdio.h>
int fibonacci(int n);
int main()
{
    int num;
    printf("enter number:");
    scanf("%d",&num);
    printf("fibonacci of %d : %d",num,fibonacci(num));
    return 0;
}
int fibonacci(int n)
{
    if(n==1||n==2)
    {
        return 1;
    }
    else
    {
   return(fibonacci(n-1)+fibonacci(n-2));
        
    }
    }