#include<stdio.h>
void max_min(int,int,int,int*,int*);
int main()
{
   int a,b,c,max,min;
printf("\n enter 3 numbers:\n");
scanf("\n%d%d%d",&a,&b,&c);

max_min(a,b,c,&max,&min);
printf("%d is maximum",max);
printf("%d is minimum",min);

return 0;
}

void max_min(int a,int b,int c,int*max,int*min)
{
*max=(a>b)?(a>c?a:c):(b>c?b:c);
*min=(a<b)?(a<c?a:c):(b<c?b:c);

return 0;
}
