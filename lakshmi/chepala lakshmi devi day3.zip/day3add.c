#include<stdio.h>

int add(int,int);
int main()
{
int limit,i,sum=0,ans;
printf("\nenter the limit::");
scanf("%d",&limit);
ans=add(i,limit);
printf("\naddition=%d",ans);

return 0;
}
int add(int i,int limit)
{
int ans;
for(i=1;i<=limit;i++)
{
ans=limit*(limit+1)/2;
}
return ans;
}
