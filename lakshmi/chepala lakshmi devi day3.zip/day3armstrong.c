#include<stdio.h>
int armstrong(int);
int main()
{
int n,temp;
printf("enter a number:");
scanf("%d",&n);
armstrong(n);
return 0;
}
int  armstrong(int n)
{
int temp=n;
int sum=0;
while(n!=0)
{
int rem;
rem=n%10;
sum=sum+(rem*rem*rem);
n=n/10;
}
if(temp==sum)
{
printf("armstrong number");
}
else
{
printf("not armstrong number");
}
}