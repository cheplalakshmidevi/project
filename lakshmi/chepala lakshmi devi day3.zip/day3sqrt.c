#include<stdio.h>
float sqr(int num);
int main()
{
  int x;
  float res;
  printf("enter number");
  scanf("%d",&x);
  res=sqr(x);
  printf("sqare root of %d is:%f",x,res);
  return 0;
}
float sqr(int num)
{
float res;
res=sqrt(num);
return res;
}