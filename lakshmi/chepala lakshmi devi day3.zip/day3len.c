#include<stdio.h>
int main()
{
  int num,count=0;
printf("enter number\n");
scanf("%d",&num);
count=len(num);
printf("number of digits is %d",count);
return 0;
}
int len(int n)
{
   int count=0;
while(n!=0)
{
n=n/10;
count++;
}
return count;
}