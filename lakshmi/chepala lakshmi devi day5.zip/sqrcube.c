#include<stdio.h>
#define SQUARE(a) a*a
#define CUBE(a) SQUARE(a)*a
int main()
{
    printf("\n square of given number is %d",SQUARE(3));
    printf("\n cube of given number is %d",CUBE(3));
    return 0;
}