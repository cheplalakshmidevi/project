#include<stdio.h>
#define MAX3(n1,n2,n3) (n1>n2)?(n1>n3?n1:n3):(n2>n3?n2:n3)
#define MAX2(m1,m2)(m1>m2)?m1:m2

int main()
{
    printf("\n max3=%d",MAX3(9,18,3));
    printf("\n max2=%d",MAX2(10,60));
    
    return 0;
}
