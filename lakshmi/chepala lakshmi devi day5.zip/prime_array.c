#include<stdio.h>
#define SIZE 25
void prime(int);

int main()
{
    int arr[SIZE];
    int i,num;
    prime(num);
    return 0;
    
}
void prime(int num)
{
    for(num=1;num<=100;num++)
    {
        int i;
        int count=0;
        for(i=2;i<=num/2;i++)
        {
            if(num%i==0)
            {
                count++;
                break;
            }
        }
        if(count==0 && num!=1)
        {
            printf("%d\n",num);
        }
            }
        }
