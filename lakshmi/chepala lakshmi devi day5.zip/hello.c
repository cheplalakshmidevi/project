#include<stdio.h>
#define PRINT
int main()
{
    printf("\n hello");
    return 0;
}