#include<stdio.h>
#define ADDITION +
#define ADD(a1,a2) a1+a2
#define SUBTRACTION -
#define SUB(a1,a2) a1-a2
#define MULTIPLICATION *
#define MUL(a1,a2) a1*a2
#define DIVISION /
#define DIV(a1,a2) a1/a2

int main()
{
    int a1,a2;
    char choice;
    printf("\nenter your choice:");
    scanf("%c",&choice);
    printf("\nenter numbers:");
    scanf("%d %d",&a1,&a2);
    switch(choice)
    
    
    {
        case '+':
{ 
        printf("\n addition=%d",ADD(a1,a2));
        break;
}
        case '-':
{
        printf("\n subtraction=%d",SUB(a1,a2));
        break;
}
        case '*':
{
        printf("\n multiplication=%d",MUL(a1,a2));
        break;

}
        case '/':
{
        printf("\n division=%d",DIV(a1,a2));
        break;
    }
    default:
{
printf("INVALID");
break;
}
}
return 0;
}

    

