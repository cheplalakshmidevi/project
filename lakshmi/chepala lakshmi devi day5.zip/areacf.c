#include<stdio.h>
#define PI 3.14
#define CIRCLE 1
#define AREAC(r) PI*r*r
#define PERIMETERC(r) 2*PI*r
#define TRIANGLE 2
#define AREAT(b,h) (b*h)/2
#define PERIMETERT(x,y,z) x+y+z
#define SQUARE 3
#define AREAS(s) s*s
#define PERIMETERS(s) 4*s
#define RECTANGLE 4
#define AREAR(l,w) l*w
#define PERIMETERR(l,w) 2*(l+w)

int main()
{
    int choice;
float r,s,b,h,x,y,z,l,w;
    printf("enter choice::");
    scanf("%d",&choice);
printf("1.circle 2.triangle 3.square 4.rectangle\n");
    
        switch(choice)
        {
        case 1:
       {
printf("enter radius:\n");
scanf("%f",&r);
 printf("the area of circle:%f",AREAC(r));
         printf("the perimeter of circle:%f",PERIMETERC(r));
         break;
}

         case 2:
{
printf("enter base and height of triangle\n");
scanf("%f%f",&b,&h);

        printf("the area of triangle:%f",AREAT(b,h));
printf("enter sides of a triangle\n");
scanf("%f%f%f",&x,&y,&z);
         printf("the perimeter of triangle:%f",PERIMETERT(x,y,z));
         break;
}
         case 3:
{
printf(" enter side of square:");
scanf("%f",&s);
        printf("the area of square:%f",AREAS(s));
         printf("the perimeter of square:%f",PERIMETERS(s));
         break;
}
         case 4:
{
printf("enter length of rectangle\n");
scanf("%f",&l);
printf("enter width of rectangle\n");
scanf("%f",&w);
        printf("the area of rectangle:%f",AREAR(l,w));
         printf("the perimeter of rectangle:%f",PERIMETERR(l,w));
         break;
}
default:
{
printf("INVALID");
break;
    }
}
return 0;
}