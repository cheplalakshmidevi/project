#include<stdio.h>
#define SIZE 26
int alphabet(int[],char);
int main()
{
    int arr[SIZE];
    char ch;
    printf("alphabets from A to Z are:\n");
    alphabet(arr[SIZE],ch);
    return 0;
    
}
int alphabet(int arr[SIZE],char ch)
{
    for(ch='A';ch<='Z';ch++)
    {
        printf("%c\n",ch);
    }
    return 0;
    }
