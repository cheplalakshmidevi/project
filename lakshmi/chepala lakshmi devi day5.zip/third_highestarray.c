#include<stdio.h>
#include <limits.h>
void thirdHighest(int arr[], int arr_size)
{
  if(arr_size < 3){
    printf(" Invalid Input ");
    return;
  }
  
  int first = arr[0];
  for (int i=1;i<arr_size;i++)
     if(arr[i] > first)
       first = arr[i];

  int second = INT_MIN;
  for (int i=0;i<arr_size;i++)
     if(arr[i] > second && arr[i] < first)
       second = arr[i];

  int third= INT_MIN;
  for (int i=0;i<arr_size;i++)
     if(arr[i] > third && arr[i] < second)
       third = arr[i];
  printf("The third highest element is %d\n",third);
}


int main()
{
   int arr[] = {12,47,7,24,98};
   int n = sizeof(arr) / sizeof(arr[0]);
   thirdHighest(arr,n);
   return 0;
}


