#include<stdio.h>
#define CHARACTER(ch) ((ch>'a'&& ch<='z')||(ch>='A'&&ch<='Z'))?printf("it is alphabet"):printf("it is not an alphabet")
int main()
{
    char ch;
    printf("enter character:");
    scanf("%c",&ch);
    CHARACTER(ch);
    
    return 0;
}