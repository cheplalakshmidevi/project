#include<stdio.h>
#include<stdlib.h>

typedef struct LinkedList{
        int data;
        struct LinkedList *next;
}node;



void selectMenu(node*);
int displayMenu();

node* createNode();

node* addAtStart(node*);
node* addAtEnd(node*);
node* addAtMid(node*,int);

node* deleteAtStart(node*);
node* deleteAtEnd(node*);
node* deleteAtMid(node*,int);

node* addAtPosition(node*,int,int);
node* deleteAtPosition(node*,int);

void display(node*);