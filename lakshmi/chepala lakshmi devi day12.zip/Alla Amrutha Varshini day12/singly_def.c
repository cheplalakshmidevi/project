#include"singly.h"
int displayMenu(){
        int ch;
        printf("\n\n------------Menu---------------");
        printf("\n\t1.Start\
                \n\t2.AddAtStart\
                \n\t3.AddAtEnd\
                \n\t4.AddAtMid\
                \n\t5.DeleteAtStart\
                \n\t6.DeleteAtEnd\
                \n\t7.DeleteAtMid\
                \n\t8.AddAtPosition\
                \n\t9.DeleteAtPostion\
                \n\t99.Display\
                \n\t0.EXIT");
        printf("\nEnter your choice::");
        scanf("%d",&ch);
        return ch;
}//end of display menu

void selectMenu(node *head){
        int ch=0,num=0,pos=0;
        do{
                system("clear");
                ch=displayMenu();
                switch(ch){
                        case 1: head=createNode();
                                printf("\n\t New Linked List instantiated\n");
                                getchar();
                                printf("\n\tPress any key to continue...");
                                getchar();
                                break;
                        case 2: head=addAtStart(head);
                                break;
                        case 3: head=addAtEnd(head);
                                break;
                        case 4: printf("\nEnter data to search :");
                                scanf("%d",&num);
                                head=addAtMid(head,num);
                                getchar();
				 break;
                        case 5: head=deleteAtStart(head);
                                break;
                        case 6: head=deleteAtEnd(head);
                                break;
                        case 7: printf("\nEnter data to delete:");
                                scanf("%d",&num);
                                head=deleteAtMid(head,num);
                                getchar();
                                printf("\n\tPress any key to continue..");
                                getchar();
                                break;
                        case 8: printf("\n\tEnter the position to add data:");
                                scanf("%d",&pos);
                                printf("\n\tEnter the data to add:");
                                scanf("%d",&num);
                                head=addAtPosition(head,pos,num);
                                getchar();
                                printf("\n\tPress any key to continue..");
                                getchar();
                                break;
                        case 9: printf("\n\tEnter position to delete the data:");
                                scanf("%d",&pos);
                                head=deleteAtPosition(head,pos);
                                getchar();
                                printf("\n\tPress any key to continue..");
                                getchar();
                                break;
                        case 99: printf("\n\n----------------------------------------\n\t");
                                 display(head);
                                 printf("\n------------------------------------------\n");
                                 getchar();
                                 printf("\n\tPress any key to continue.....");
                                 getchar();
                                 break;
                        default: printf("\n\tWrong Choice::");
                                 break;
			 case 0: exit(0);
                }
        }while(ch!=0);
}//end of select menu

node *createNode(){
        node *newnode;
        newnode=(node*)malloc(sizeof(node));
        printf("\nEnter data::");
        scanf("%d",&newnode->data);
        newnode->next=NULL;
        return newnode;
}//end of create new node


node* addAtStart(node *head){
        node *newnode=createNode();
        if(head==NULL)
                head=newnode;
        else{
                newnode->next=head;
                head=newnode;
        }
        return head;
}//end of adding node at starting of list


node* addAtEnd(node *head){
        node *newnode=createNode();
        node *temp=head;
        if(head==NULL)
                head=newnode;
        else{
                while(temp->next!=NULL)
                        temp=temp->next;
                temp->next=newnode;
        }
        return head;
}//end of adding node at ending of list
node* addAtMid(node *head,int num){
        node *temp=head;
        node *newnode=createNode();

        if(head==NULL)
                head=newnode;
        else if(head->next==NULL){
                if(head->data==num){
                        head->next=newnode;
                }
                else
                        printf("\n\tERROR: Node not found");
        }
        else
        {
                while(temp!=NULL && temp->data!=num)
                        temp=temp->next;
                if(temp!=NULL){
                        newnode->next=temp->next;
                        temp->next=newnode;
                }
                else
                        printf("\n\tERROR: Node not found");
        }
        return head;
}//end of adding node in the middle of linked list


node* deleteAtStart(node *head){
        node *temp=head;
        if(head==NULL)
                printf("\n\tERROR: Linked List is Empty...");
        else{
                head=head->next;
                free(temp);
        }
        return 0;
}

node* deleteAtEnd(node *head){
        node *temp=head;
        if(head==NULL)
                printf("\n\tERROR: Linked list is empty..");
        else if(head->next==NULL)
        {
                head=NULL;
                free(temp);
        }
        else{
                while(temp->next->next!=NULL)
                        temp=temp->next;
                free(temp->next);
                temp->next=NULL;
        }
        return head;
}


node* deleteAtMid(node *head,int num){
        node *temp=head;
        node *tag=head;
        if(head==NULL)
                printf("\n\tLinked list is empty..");
        else if(head->next == NULL){
                if(head->data==num){
                        head=NULL;
                        free(temp);
                }
                else
                        printf("\n\tERROR: Node not found");
        }
        else{
                while(temp!=NULL && temp->data != num){
                        tag=temp;
                        temp=temp->next;
                }
                if(temp!=NULL){
                        tag->next=temp->next;
			free(temp);
                }
        t       else
                        printf("\n\tERRROR: Node not found");
        }
        return head;
}


node* addAtPosition(node *head,int pos,int num){
        node *ptr,*temp;
        int i,pos;

        temp=(struct node*)malloc(sizeof(struct node));
        if(temp==NULL){
                printf("\nOut of Memory Space:");
        }
        printf("\nEnter position for the new node to be inserted:");
        scanf("%d",&pos);
        printf("\nEnter the data value of node:");
        scanf("%d",&temp->data);
        temp->next=NULL;
        if(pos==0){
                temp->next=head;
                head=temp;
        }
        else{
                for(i=0,ptr=head;i<pos-1;i++){
                        ptr=ptr->next;
                        if(ptr==NULL){
                                printf("\nPosition not found:");
                        }
                        temp->next=ptr->next;
                        ptr->next=temp;
                }
        }
        return head;
}

node* deleteAtPosition(int *head,int pos){
        int i;
        node *temp,*ptr;
        if(head==NULL){
                printf("\nThe list is Empty:");
                exit(0);
        }
        else{
                if(pos==0){
                        ptr=head;
                        head=head->next;
                        printf("\nThe deleted element is:%d",ptr->data);
                        free(ptr);
                }
                else{
                        ptr=temp;
                        for(i=0;i<pos;i++){
                                temp=ptr;
                                ptr=ptr->next;
                                if(ptr==NULL){
                                        printf("\nPosition not Found:");
                                        return;
                                }
                        }
                        temp->next=ptr->next;
                        printf("\nThe deleted element is:%d",ptr->data);
                        free(ptr);
                }
        }
        return head;
}


void display(node *head){
        node *temp=head;
        if(head==NULL)
                printf("\n\tLinked List is empty...!!");
        else{
                while(temp!=NULL){
			printf("%d->",temp->data);
                        temp=temp->next;
                }
                printf("NULL\n");
        }
}//end display