#include"singly.h"
int main(){
        node *head=NULL;
        selectMenu(head);
        return 0;
}